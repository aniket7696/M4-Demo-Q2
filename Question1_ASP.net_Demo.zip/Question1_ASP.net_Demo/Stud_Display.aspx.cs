﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Question1_ASP.net_Demo
{
    public partial class Stud_Display : System.Web.UI.Page
    {
        SqlConnection conn = null;
        SqlDataReader dr = null;
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
            cmd = new SqlCommand();

            try
            {
                cmd = new SqlCommand("SELECT * FROM STUDENT_MASTER", conn);
                conn.Open();
                dr=cmd.ExecuteReader();
                DataTable dt = new DataTable();
                if (dr.HasRows)
                    dt.Load(dr);
                conn.Close();
                gvStud.DataSource = dt;
                gvStud.DataBind();
                    
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);

            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

        }
    }
}