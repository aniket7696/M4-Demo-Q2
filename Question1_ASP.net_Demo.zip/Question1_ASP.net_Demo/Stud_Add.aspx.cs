﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Question1_ASP.net_Demo
{
    public partial class Stud_Add : System.Web.UI.Page
    {
        SqlConnection conn = null;
        SqlDataReader dr = null;
        SqlCommand cmd = null;

        public Stud_Add()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
            cmd = new SqlCommand();
            
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            

        }


        public void AddStudent()
        {
            try
            {
                cmd = new SqlCommand("INSERT INTO STUDENT_MASTER VALUES(@id,@sname,@deptCode,@sDob,@sAdd)", conn);
                
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtStudId.Text));
                cmd.Parameters.AddWithValue("@sname", txtStudName.Text);
                cmd.Parameters.AddWithValue("@sDob", Convert.ToDateTime(txtStudDob.Text));
                cmd.Parameters.AddWithValue("@deptCode", Convert.ToInt32(txtStudDeptCode.Text));
                cmd.Parameters.AddWithValue("@sAdd", txtStdAdd.Text);
                conn.Open();
                int recAffected=cmd.ExecuteNonQuery();

                
            if(recAffected>0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Inserted Successfully')</script>");
                

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Not Inserted Successfully')</script>");
            }  
                
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            AddStudent();
        }
    }
}