﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Question1_ASP.net_Demo
{
    public partial class Stud_Delete : System.Web.UI.Page
    {
        SqlConnection conn = null;
        SqlDataReader dr = null;
        SqlCommand cmd = null;

        public Stud_Delete()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
            cmd = new SqlCommand();
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDelStud_Click(object sender, EventArgs e)
        {
            Delete();

        }

        public void Delete()
        {
            try
            {
                cmd = new SqlCommand("DELETE FROM STUDENT_MASTER WHERE STUD_CODE = @id", conn);

                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtStudId.Text));
               
                conn.Open();
                int recAffected = cmd.ExecuteNonQuery();


                if (recAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Deleted Successfully')</script>");


                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Not Deleted Successfully')</script>");
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
    }
}