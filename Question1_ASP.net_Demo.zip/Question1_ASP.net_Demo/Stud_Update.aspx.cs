﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Question1_ASP.net_Demo
{
    public partial class Stud_Update : System.Web.UI.Page
    {
        SqlConnection conn = null;
        SqlDataReader dr = null;
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public Stud_Update()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
            cmd = new SqlCommand();
        }

        protected void btnUpdateStud_Click(object sender, EventArgs e)
        {
            Update();
        }

        public void Update()
        {
            try
            {
                cmd = new SqlCommand("UPDATE STUDENT_MASTER SET STUD_NAME=@stud_name WHERE STUD_CODE = @id", conn);

                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtStudId.Text));
                cmd.Parameters.AddWithValue("@stud_name", txtStudName.Text);
                conn.Open();
                int recAffected = cmd.ExecuteNonQuery();


                if (recAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Updated Successfully')</script>");


                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Not Updated Successfully')</script>");
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
    }
}